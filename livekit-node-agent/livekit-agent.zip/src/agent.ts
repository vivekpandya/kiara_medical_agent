import {
  type JobContext,
  type JobProcess,
  WorkerOptions,
  cli,
  defineAgent,
  llm,
  metrics,
  voice,
} from '@livekit/agents';
import * as cartesia from '@livekit/agents-plugin-cartesia';
import * as deepgram from '@livekit/agents-plugin-deepgram';
import * as livekit from '@livekit/agents-plugin-livekit';
import * as openai from '@livekit/agents-plugin-openai';
import * as silero from '@livekit/agents-plugin-silero';
import { BackgroundVoiceCancellation } from '@livekit/noise-cancellation-node';
import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';

dotenv.config({ path: '.env.local' });

// Main Kiara Agent - Healthcare Support Assistant
class KiaraAgent extends voice.Agent {
  constructor() {
    super({
      instructions: `You are Kiara, a helpful and friendly voice AI assistant for a healthcare support system.
      When you first connect, greet the user by saying: "Hi, I am Kiara. How can I help you today?"
      You can help users with various healthcare tasks including:
      - Setting medication reminders
      - Checking drug interactions
      - Getting detailed drug information
      - Analyzing symptoms
      - General healthcare questions
      
      When users ask for specific services, guide them to use the appropriate tools.
      Your responses are concise, to the point, and without any complex formatting or punctuation including emojis, asterisks, or other symbols.
      You are curious, friendly, and have a sense of humor.`,
      tools: {
        getWeather: llm.tool({
          description: `Use this tool to look up current weather information in the given location.
 
          If the location is not supported by the weather service, the tool will indicate this. You must tell the user the location's weather is unavailable.`,
          parameters: z.object({
            location: z
              .string()
              .describe('The location to look up weather information for (e.g. city name)'),
          }),
          execute: async ({ location }) => {
            console.log(`Looking up weather for ${location}`);
            return 'sunny with a temperature of 70 degrees.';
          },
        }),
        add_reminder: llm.tool({
          description: 'Switch to ReminderAgent to set up medication reminders',
          parameters: z.object({}),
          execute: async () => {
            console.log('[KiaraAgent] Switching to ReminderAgent');
            return { switchTo: 'reminder' };
          },
        }),
        drug_interaction: llm.tool({
          description: 'Switch to DrugInteractionAgent to check drug interactions',
          parameters: z.object({}),
          execute: async () => {
            console.log('[KiaraAgent] Switching to DrugInteractionAgent');
            return { switchTo: 'drug_interaction' };
          },
        }),
        drug_detail: llm.tool({
          description: 'Switch to DrugDetailAgent to get detailed drug information',
          parameters: z.object({}),
          execute: async () => {
            console.log('[KiaraAgent] Switching to DrugDetailAgent');
            return { switchTo: 'drug_detail' };
          },
        }),
        symptom_checker: llm.tool({
          description: 'Switch to SymptomCheckerAgent to analyze symptoms',
          parameters: z.object({}),
          execute: async () => {
            console.log('[KiaraAgent] Switching to SymptomCheckerAgent');
            return { switchTo: 'symptom_checker' };
          },
        }),
        logConversation: llm.tool({
          description: 'No-op logger to acknowledge conversation logging requests',
          parameters: z.object({ text: z.string() }),
          execute: async ({ text }) => {
            try {
              console.log('[Agent] logConversation noop', text);
            } catch (_) {}
            return 'acknowledged';
          },
        }),
      },
    });
  }
}

// Reminder Agent - Handles medication reminders
class ReminderAgent extends voice.Agent {
  private reminderSaved: boolean = false;

  constructor() {
    super({
      instructions: `You are a medical agent communicating by voice. Your task is to collect medication reminder information from the user.

      Ask the user for:
      1. The medicine name
      2. The timing to take it (e.g., "8 AM daily", "twice a day at 8 AM and 9 PM")

      Once you have BOTH pieces of information, call the save_reminder function with the details.
      After saving, you can help with other questions or switch to Kiara for general assistance.

      Be conversational, friendly, and natural. Don't mention JSON or technical details to the user.`,
      tools: {
        save_reminder: llm.tool({
          description: 'Save the medication reminder details',
          parameters: z.object({
            medicine: z.string().describe('Name of the medication'),
            timing: z.string().describe('When to take the medication'),
          }),
          execute: async ({ medicine, timing }) => {
            const reminderData = {
              medicine,
              timing,
              timestamp: new Date().toISOString(),
            };

            // Send to service asynchronously (non-blocking)
            this.sendToService(reminderData).catch((err) =>
              console.error('Failed to send reminder:', err)
            );

            this.reminderSaved = true;
            console.log('📝 Reminder captured:', JSON.stringify(reminderData, null, 2));

            return `Perfect! I've set up your reminder for ${medicine} at ${timing}. What else can I help you with?`;
          },
        }),
        switch_to_kiara: llm.tool({
          description: 'Switch back to Kiara for general assistance',
          parameters: z.object({}),
          execute: async () => {
            return { switchTo: 'kiara' };
          },
        }),
        switch_to_drug_interaction_agent: llm.tool({
          description: 'Switch to DrugInteractionAgent to check medication interactions',
          parameters: z.object({}),
          execute: async () => {
            return { switchTo: 'drug_interaction' };
          },
        }),
        switch_to_drug_detail_agent: llm.tool({
          description: 'Switch to DrugDetailAgent for medication information',
          parameters: z.object({}),
          execute: async () => {
            return { switchTo: 'drug_detail' };
          },
        }),
        switch_to_symptom_checker_agent: llm.tool({
          description: 'Switch to SymptomCheckerAgent',
          parameters: z.object({}),
          execute: async () => {
            return { switchTo: 'symptom_checker' };
          },
        }),
      },
    });
  }

  private async sendToService(data: any): Promise<void> {
    try {
      const response = await fetch('https://your-service.com/api/reminders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      console.log(`✓ Reminder sent to service: ${response.status}`);
    } catch (error) {
      console.error('✗ Failed to send reminder to service:', error);
    }
  }
}

// Drug Interaction Agent
class DrugInteractionAgent extends voice.Agent {
  constructor() {
    super({
      instructions: `You are a medical analyst capable of classifying drug, food and therapeutic duplication interaction pairs as major, moderate, or minor, and you must respond in JSON. The JSON schema should include:

      Major: drug interactions combination with major risk in 200 words,
      Moderate: drug interactions combination with moderate risk in 200 words,
      Minor: drug interactions combination with minor risk in 200 words,
      No Interaction: no drug interactions found

      1. Major:
      High clinical risk that can cause severe, life-threatening, or irreversible harm. Avoid the combination entirely, as the risks outweigh the benefits.
      Examples include drugs with extreme toxicity, fatal arrhythmias, severe bleeding risk, or organ failure.

      2. Moderate:
      Noticeable clinical risk but not immediately life-threatening.
      Avoid unless necessary; requires close monitoring or dose adjustments.
      Risks can often be managed with precautionary measures like adjusting timing, using an antidote, or monitoring blood levels.

      3. Minor:
      Minimal clinical risk with mild or insignificant effects.
      Generally safe to use together with minor precautions.
      Adjustments like dose timing or alternative selection may further reduce risk.

      Rules:
      1. Classify a combination into only one category at a time.
      2. Ignore a key if no interactions are found.
      3. Name the medications; avoid using pronouns like it or they and use the drug names instead.
      4. Use a full sentence without a colon, such as "The combination of Drug1 and Drug2 may increase the risk of...".
      5. Remove empty keys from the JSON output.`,
      tools: {
        switch_to_kiara: llm.tool({
          description: 'Switch back to Kiara',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'kiara' }),
        }),
        switch_to_add_reminder: llm.tool({
          description: 'Switch to ReminderAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'reminder' }),
        }),
        switch_to_drug_detail_agent: llm.tool({
          description: 'Switch to DrugDetailAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'drug_detail' }),
        }),
        switch_to_symptom_checker_agent: llm.tool({
          description: 'Switch to SymptomCheckerAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'symptom_checker' }),
        }),
      },
    });
  }
}

// Drug Detail Agent
class DrugDetailAgent extends voice.Agent {
  constructor() {
    super({
      instructions: `User will give you the medical drugs. You need to find the drug-drug, drug-food and therapeutic duplication.`,
      tools: {
        switch_to_kiara: llm.tool({
          description: 'Switch back to Kiara',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'kiara' }),
        }),
        switch_to_add_reminder: llm.tool({
          description: 'Switch to ReminderAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'reminder' }),
        }),
        switch_to_drug_interaction: llm.tool({
          description: 'Switch to DrugInteractionAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'drug_interaction' }),
        }),
        switch_to_symptom_checker_agent: llm.tool({
          description: 'Switch to SymptomCheckerAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'symptom_checker' }),
        }),
      },
    });
  }
}

// Symptom Checker Agent
class SymptomCheckerAgent extends voice.Agent {
  constructor() {
    super({
      instructions: `You are a medical AI agent. You need to provide only the names of possible medical conditions or causes based on the symptoms, gender, age, and country provided by the user in JSON format:
      {
        "condition_1": "first condition name",
        "condition_2": "second condition name",
        "condition_3": "third condition name",
        // Include as many medical conditions as you think in decreasing order of probability
      }
      Give at least 10 results.`,
      tools: {
        switch_to_kiara: llm.tool({
          description: 'Switch back to Kiara',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'kiara' }),
        }),
        switch_to_add_reminder: llm.tool({
          description: 'Switch to ReminderAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'reminder' }),
        }),
        switch_to_drug_interaction_agent: llm.tool({
          description: 'Switch to DrugInteractionAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'drug_interaction' }),
        }),
        switch_to_drug_detail_agent: llm.tool({
          description: 'Switch to DrugDetailAgent',
          parameters: z.object({}),
          execute: async () => ({ switchTo: 'drug_detail' }),
        }),
      },
    });
  }
}

export default defineAgent({
  prewarm: async (proc: JobProcess) => {
    proc.userData.vad = await silero.VAD.load();
  },
  entry: async (ctx: JobContext) => {
    console.log('[Agent] Starting Kiara multi-agent medical system');
    console.log('[Agent] Using LLM endpoint', process.env.OPENAI_BASE_URL, 'model', process.env.OPENAI_MODEL ?? 'llama-3.1-8b-instant');

    // Choose LLM endpoint and model (force supported Groq model if env is invalid)
    const rawBaseUrl = process.env.OPENAI_BASE_URL?.trim() || 'https://api.groq.com/openai/v1';
    const normalizedBaseUrl = /\/v1\/?$/.test(rawBaseUrl)
      ? rawBaseUrl.replace(/\/$/, '')
      : `${rawBaseUrl.replace(/\/$/, '')}/v1`;
    const envModel = (process.env.OPENAI_MODEL || '').trim();
    const chosenModel = !envModel || /instruct/i.test(envModel)
      ? 'llama-3.1-8b-instant'
      : envModel;
    console.log('[Agent] LLM resolved -> baseURL:', normalizedBaseUrl, 'model:', chosenModel);

    // Set up a voice AI pipeline using OpenAI-compatible (can be GROQ), Cartesia, Deepgram, and the LiveKit turn detector
    const session = new voice.AgentSession({
      // A Large Language Model (LLM) is your agent's brain, processing user input and generating a response
      // See all providers at https://docs.livekit.io/agents/integrations/llm/
      // Configure GROQ (OpenAI‑compatible) explicitly: baseURL must include /openai/v1
      // Groq supports models like 'llama-3.1-70b-versatile' and 'llama-3.1-8b-instant'
      llm: new openai.LLM({
        model: chosenModel,
        baseURL: normalizedBaseUrl,
      }),
      // Speech-to-text (STT) is your agent's ears, turning the user's speech into text that the LLM can understand
      // See all providers at https://docs.livekit.io/agents/integrations/stt/
      stt: new deepgram.STT({ model: 'nova-3' }),
      // Text-to-speech (TTS) is your agent's voice, turning the LLM's text into speech that the user can hear
      // See all providers at https://docs.livekit.io/agents/integrations/tts/
      tts: new cartesia.TTS({
        voice: '6f84f4b8-58a2-430c-8c79-688dad597532',
      }),
      // VAD and turn detection are used to determine when the user is speaking and when the agent should respond
      // Replace ONNX multilingual model (crashes on some Windows PCs) with lightweight energy model
      // Fallback: disable turn detection entirely to keep TTS working
      turnDetection: (() => {
        const EnergyModel = (livekit as any)?.turnDetector?.EnergyModel;
        if (EnergyModel) {
          return new EnergyModel({ endSilenceMs: 700, beginThreshold: 0.45, endThreshold: 0.35 });
        }
        return false as any;
      })(),
      vad: ctx.proc.userData.vad! as silero.VAD,
    });

    // Metrics collection, to measure pipeline performance
    // For more information, see https://docs.livekit.io/agents/build/metrics/
    const usageCollector = new metrics.UsageCollector();
    session.on(voice.AgentSessionEventTypes.MetricsCollected, (ev) => {
      metrics.logMetrics(ev.metrics);
      usageCollector.collect(ev.metrics);
    });

    const logUsage = async () => {
      const summary = usageCollector.getSummary();
      console.log(`Usage: ${JSON.stringify(summary)}`);
    };

    ctx.addShutdownCallback(logUsage);

    // Start the session with Kiara as the main agent
    await session.start({
      agent: new KiaraAgent(),
      room: ctx.room,
      inputOptions: {
        // LiveKit Cloud enhanced noise cancellation
        // - If self-hosting, omit this parameter
        // - For telephony applications, use `BackgroundVoiceCancellationTelephony` for best results
        noiseCancellation: BackgroundVoiceCancellation(),
      },
    });

    // Use LiveKit's built-in transcription forwarding instead of custom data channels
    // This automatically forwards STT and TTS transcriptions to the frontend
    console.log('[Agent] Using LiveKit built-in transcription forwarding');

    // Join the room and connect to the user
    // Connect to the target room. The connect() signature accepts only E2EE
    // options; room selection is handled by the job scheduler / token. Since
    // we already requested a token for the desired room from the frontend,
    // simply call connect() without extra arguments.
    await ctx.connect();

    // Auto-greet the user when they connect
    console.log('[Agent] Sending automatic greeting from Kiara');
    try {
      // Give a moment for the connection to stabilize
      await new Promise(resolve => setTimeout(resolve, 1000));
      await session.say('Hi, I am Kiara. How can I help you today?');
      console.log('[Agent] Greeting sent successfully');
    } catch (e) {
      console.warn('[Agent] Failed to send greeting:', e);
    }

    // Note: dynamic agent switching via session APIs is not available in this SDK version.
    // If needed later, implement using supported APIs when exposed by the library.
  },
});

cli.runApp(new WorkerOptions({ agent: fileURLToPath(import.meta.url) }));

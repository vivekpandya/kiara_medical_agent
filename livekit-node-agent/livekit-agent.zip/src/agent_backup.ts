import {
  type JobContext,
  type JobProcess,
  WorkerOptions,
  cli,
  defineAgent,
  llm,
  metrics,
  voice,
} from '@livekit/agents';
import * as cartesia from '@livekit/agents-plugin-cartesia';
import * as deepgram from '@livekit/agents-plugin-deepgram';
import * as livekit from '@livekit/agents-plugin-livekit';
import * as openai from '@livekit/agents-plugin-openai';
import * as silero from '@livekit/agents-plugin-silero';
import { BackgroundVoiceCancellation } from '@livekit/noise-cancellation-node';
import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';

dotenv.config({ path: '.env.local' });

class Assistant extends voice.Agent {
  constructor() {
    super({
      instructions: `You are Kiara, a helpful and friendly voice AI assistant for a healthcare support system.
      When you first connect, greet the user by saying: "Hi, I am Kiara. How can I help you today?"
      You eagerly assist users with their questions by providing information from your extensive knowledge.
      Your responses are concise, to the point, and without any complex formatting or punctuation including emojis, asterisks, or other symbols.
      You are curious, friendly, and have a sense of humor.`,
      tools: {
        getWeather: llm.tool({
          description: `Use this tool to look up current weather information in the given location.
 
          If the location is not supported by the weather service, the tool will indicate this. You must tell the user the location's weather is unavailable.`,
          parameters: z.object({
            location: z
              .string()
              .describe('The location to look up weather information for (e.g. city name)'),
          }),
          execute: async ({ location }) => {
            console.log(`Looking up weather for ${location}`);

            return 'sunny with a temperature of 70 degrees.';
          },
        }),
        // Prevent LLM tool-call failures when prompts reference 'logConversation'
        // This is a no-op tool that simply acknowledges the request so the run
        // doesn't abort with a 400 tool validation error.
        logConversation: llm.tool({
          description: 'No-op logger to acknowledge conversation logging requests',
          parameters: z.object({ text: z.string() }),
          execute: async ({ text }) => {
            try {
              console.log('[Agent] logConversation noop', text);
            } catch (_) {}
            return 'acknowledged';
          },
        }),
      },
    });
  }
}

export default defineAgent({
  prewarm: async (proc: JobProcess) => {
    proc.userData.vad = await silero.VAD.load();
  },
  entry: async (ctx: JobContext) => {
    console.log('[Agent] Using LLM endpoint', process.env.OPENAI_BASE_URL, 'model', process.env.OPENAI_MODEL ?? 'llama-3.1-8b-instant');
    // Resolve target room: prefer env ROOM, otherwise scheduler-provided ctx.room
    // Allow overriding room via env, otherwise accept connect options from the
    // scheduler; when launching locally we also honor ROOM query param through
    // ctx.connect({ room: NAME }) below.
    const desiredRoomName = process.env.ROOM && process.env.ROOM.trim().length > 0 ? process.env.ROOM.trim() : undefined;

    // Choose LLM endpoint and model (force supported Groq model if env is invalid)
    const rawBaseUrl = process.env.OPENAI_BASE_URL?.trim() || 'https://api.groq.com/openai/v1';
    const normalizedBaseUrl = /\/v1\/?$/.test(rawBaseUrl)
      ? rawBaseUrl.replace(/\/$/, '')
      : `${rawBaseUrl.replace(/\/$/, '')}/v1`;
    const envModel = (process.env.OPENAI_MODEL || '').trim();
    const chosenModel = !envModel || /instruct/i.test(envModel)
      ? 'llama-3.1-8b-instant'
      : envModel;
    console.log('[Agent] LLM resolved -> baseURL:', normalizedBaseUrl, 'model:', chosenModel);

    // Set up a voice AI pipeline using OpenAI-compatible (can be GROQ), Cartesia, Deepgram, and the LiveKit turn detector
    const session = new voice.AgentSession({
      // A Large Language Model (LLM) is your agent's brain, processing user input and generating a response
      // See all providers at https://docs.livekit.io/agents/integrations/llm/
      // Configure GROQ (OpenAI‑compatible) explicitly: baseURL must include /openai/v1
      // Groq supports models like 'llama-3.1-70b-versatile' and 'llama-3.1-8b-instant'
      llm: new openai.LLM({
        model: chosenModel,
        baseURL: normalizedBaseUrl,
      }),
      // Speech-to-text (STT) is your agent's ears, turning the user's speech into text that the LLM can understand
      // See all providers at https://docs.livekit.io/agents/integrations/stt/
      stt: new deepgram.STT({ model: 'nova-3' }),
      // Text-to-speech (TTS) is your agent's voice, turning the LLM's text into speech that the user can hear
      // See all providers at https://docs.livekit.io/agents/integrations/tts/
      tts: new cartesia.TTS({
        voice: '6f84f4b8-58a2-430c-8c79-688dad597532',
      }),
      // VAD and turn detection are used to determine when the user is speaking and when the agent should respond
      // Replace ONNX multilingual model (crashes on some Windows PCs) with lightweight energy model
      // Fallback: disable turn detection entirely to keep TTS working
      turnDetection: (() => {
        const EnergyModel = (livekit as any)?.turnDetector?.EnergyModel;
        if (EnergyModel) {
          return new EnergyModel({ endSilenceMs: 700, beginThreshold: 0.45, endThreshold: 0.35 });
        }
        return false as any;
      })(),
      vad: ctx.proc.userData.vad! as silero.VAD,
    });

    // To use a realtime model instead of a voice pipeline, use the following session setup instead:
    // const session = new voice.AgentSession({
    //   // See all providers at https://docs.livekit.io/agents/integrations/realtime/
    //   llm: new openai.realtime.RealtimeModel({ voice: 'marin' }),
    // });

    // Metrics collection, to measure pipeline performance
    // For more information, see https://docs.livekit.io/agents/build/metrics/
    const usageCollector = new metrics.UsageCollector();
    session.on(voice.AgentSessionEventTypes.MetricsCollected, (ev) => {
      metrics.logMetrics(ev.metrics);
      usageCollector.collect(ev.metrics);
    });

    const logUsage = async () => {
      const summary = usageCollector.getSummary();
      console.log(`Usage: ${JSON.stringify(summary)}`);
    };

    ctx.addShutdownCallback(logUsage);

    // Start the session, which initializes the voice pipeline and warms up the models
    await session.start({
      agent: new Assistant(),
      room: ctx.room,
      inputOptions: {
        // LiveKit Cloud enhanced noise cancellation
        // - If self-hosting, omit this parameter
        // - For telephony applications, use `BackgroundVoiceCancellationTelephony` for best results
        noiseCancellation: BackgroundVoiceCancellation(),
      },
    });

    // Use LiveKit's built-in transcription forwarding instead of custom data channels
    // This automatically forwards STT and TTS transcriptions to the frontend
    console.log('[Agent] Using LiveKit built-in transcription forwarding');

    // Join the room and connect to the user
    // Connect to the target room. The connect() signature accepts only E2EE
    // options; room selection is handled by the job scheduler / token. Since
    // we already requested a token for the desired room from the frontend,
    // simply call connect() without extra arguments.
    await ctx.connect();

    // Auto-greet the user when they connect
    console.log('[Agent] Sending automatic greeting');
    try {
      // Give a moment for the connection to stabilize
      await new Promise(resolve => setTimeout(resolve, 1000));
      await session.say('Hi, I am Kiara. How can I help you today?');
      console.log('[Agent] Greeting sent successfully');
    } catch (e) {
      console.warn('[Agent] Failed to send greeting:', e);
    }
  },
});

cli.runApp(new WorkerOptions({ agent: fileURLToPath(import.meta.url) }));